create host master.local
to connect - vagrant ssh

